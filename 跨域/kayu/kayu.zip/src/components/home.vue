<template>
    <div>
        <h1>你好</h1>
    </div>
</template>

<script>
export default {
    data(){
        return{

        }
    },
    created(){
        this.init()
    },
    methods:{
        init(){

        }
    }   

}
</script>

<style>

</style>
